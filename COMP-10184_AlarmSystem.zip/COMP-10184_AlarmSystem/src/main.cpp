#include <Arduino.h>

// digital input pin definitions 
#define PIN_PIR D5 
#define PIN_BUTTON D6 

bool alarmActivated = false;
bool alarmDisarmed = false;

void setup() {
  // put your setup code here, to run once:

  // configure the USB serial monitor 
  Serial.begin(115200); 
 
  // configure the LED output 
  pinMode(LED_BUILTIN, OUTPUT); 
 
  // PIR sensor is an INPUT 
  pinMode(PIN_PIR, INPUT); 
 
  // Button is an INPUT 
  pinMode(PIN_BUTTON, INPUT_PULLUP); 

  digitalWrite(LED_BUILTIN, HIGH);
  
}

void loop() {
  // put your main code here, to run repeatedly:

  bool bPIR; 
  int button;
 
  // read PIR sensor (true = Motion detected!).  As long as there 
  // is motion, this signal will be true.  About 2.5 seconds after  
  // motion stops, the PIR signal will become false. 
  bPIR = digitalRead(PIN_PIR); 
  button = digitalRead(PIN_BUTTON);

  // send the PIR signal directly to the LED 
  // but invert it because true = LED off! 
  if (bPIR && alarmActivated == false) {

    for (int i = 0; i < 10; i++) { // 10 Seconds

      if (!button) {
        alarmDisarmed = true;
        break;
      }

      digitalWrite(LED_BUILTIN, LOW); // 1
      delay(142);
      digitalWrite(LED_BUILTIN, HIGH);
      delay(142);
      digitalWrite(LED_BUILTIN, LOW); // 2
      delay(142);
      digitalWrite(LED_BUILTIN, HIGH);
      delay(142);
      digitalWrite(LED_BUILTIN, LOW); // 3
      delay(142);
      digitalWrite(LED_BUILTIN, HIGH);
      delay(142);
      digitalWrite(LED_BUILTIN, LOW); // 4
      delay(142);
      digitalWrite(LED_BUILTIN, HIGH);

      // Aprox. 1 sec passed
      // Loop 10 times = 10 seconds - 4 blinks / second
      // 1000ms / 7 delay statements = ~142
    }

    if (!alarmDisarmed) {
      digitalWrite(LED_BUILTIN, LOW); // Stage 3
      alarmActivated = true;
    }

    delay(5000); // 5 seconds for the alarm to reset
    
  }

}